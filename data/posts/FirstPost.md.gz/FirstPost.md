﻿---
title: "This is First Post In BoneLog !"
date: "2025-05-29"
tags: ["BoneLog"]
cover: "/images/Logo.jpg"
thumbnail : "/images/Logo.jpg"
shortDescription : "this is my first post in bonelog, jsut for test"
---

Hi guys this is my first post.



```csharp
Console.WriteLine("Hello BloneLog");
```
