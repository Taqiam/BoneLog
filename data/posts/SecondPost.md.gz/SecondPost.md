﻿---
title: "This is Second Post In BoneLog !"
date: "2025-05-30"
tags: ["BoneLog"]
cover: "images/Logo.jpg"
thumbnail : "images/Logo.jpg"
shortDescription : "this is my second post in bonelog, jsut for test"
---

Hi guys this is my second post.

```cpp
#include <iostream>

int main() {
    std::cout << "Hello BoneLog!";
    return 0;
}
```
